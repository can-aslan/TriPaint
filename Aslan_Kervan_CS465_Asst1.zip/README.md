# TriPaint 
### CS465 Fall 2023-2024 Assignment 1: 2D Paint Application With Triangles

+ Group Member 1: Yağız Can Aslan, 22001943.
+ Group Member 2: İlkim Elif Kervan, 22002223.
